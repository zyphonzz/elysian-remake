function dbg(n)
    print("Monarch - "..n)
end

--[[
MONARCH CLIENT V3

Changed UI Lib from:
    MacLib
to:
    Fluent

(in the future, a loader/setup will be available
so you can pick which library to use.)
]]

--settings

local checkforbanwaves=true
local theme="Rose" -- Amethyst, Aqua, Rose, Light, Dark, Darker

--[[
DO NOT EDIT ANYTHING UNDER THIS LINE UNLESS YOU KNOW WHAT YOU ARE DOING

if ur just some random skid, dont bother reading the rest of the code.
]]

local function safeGet(url)
    local response = game:HttpGet(url)
    if response then
        return response
    else
        warn("Error getting URL:", url)
        return nil
    end
end

--variables

local function add(n : string,v : func)
    getgenv()[n]=v
    print("Monarch - Added "..n.." to the global environment.")
end
--removes a func from the global env
local function remove(n : string)
    getgenv()[n]=nil
    print("Monarch - Removed "..n.." from the global environment.")
end
--generates a random character
local function randomChar()
    local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local randIndex = math.random(1, #chars)
    return chars:sub(randIndex, randIndex)
end

local ctime=game.Lighting.ClockTime

local monarch = {
    ["banwaveactive"] = safeGet("https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/banwaveactive.lua"),
    ["version"] = safeGet("https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/version.luau"),
    ["devs"] = safeGet("https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/credits.luau"),
    ["isbeta"] = safeGet("https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/beta.luau") == "true",
    ["isupdating"] = safeGet("https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/updating.luau") == "true",
}

local function getdevs(pos : number)
    return monarch.devs[pos]
end

local plr=game:FindFirstChildOfClass("Players").LocalPlayer
local level=getidentity()

--main

local Fluent = loadstring(game:HttpGet("https://github.com/dawid-scripts/Fluent/releases/latest/download/main.lua"))()
local Window = Fluent:CreateWindow({
    Title = "Monarch Client",
    SubTitle = monarch.version,
    TabWidth = 160,
    Size = UDim2.fromOffset(580, 460),
    Acrylic = true,
    Theme = theme,
    MinimizeKey = Enum.KeyCode.Home,
})
local Tabs = {
    Visuals = Window:AddTab({ Title = "Visuals", Icon = "brush" }),
    Tweaks = Window:AddTab({ Title = "Tweaks", Icon = "user" }),
    Functions = Window:AddTab({ Title = "Custom Functions", Icon = "code" }),
    Scripts = Window:AddTab({ Title = "Scripts", Icon = "scroll" }),
    Archive = Window:AddTab({ Title = "Archive", Icon = "archive" }),
    Settings = Window:AddTab({ Title = "Settings", Icon = "settings" })
}

--pre boot

local esp = loadstring(game:HttpGet("https://raw.githubusercontent.com/andrewc0de/Roblox/main/Dependencies/ESP.lua"))()
esp:Toggle(false)
esp.Color=Color3.fromRGB(132, 255, 169)
esp.Boxes = true
esp.Names = false
esp.Tracers = false
esp.Players = true

--checks
if level < 6 then --exec support (cuz yeah)
    Fluent:Notify({
        Title="Monarch Client",
        Content="Your executor may not support Monarch Client. (exec level less than 6.)",
        SubContent="Recommended executors: Cloudy, Wave, Synapse Z, Nihon, AWP.GG, Sirhurt.",
        Duration=5
    })
end
if monarch.isbeta==true then --beta stuff
    Fluent:Notify({
        Title = "Monarch Client",
        Content = "You are running a beta version, Expect bugs.",
        Duration = 5 -- Set to nil to make the notification not disappear
    })
end

if monarch.banwaveactive==true then --banwave stuff
    Window:Dialog({
        Title = "Monarch Client",
        Content = "A banwave has been detected. Are you sure you would like to continue?",
        Buttons = {
            { 
                Title = "Yup",
            }, {
                Title = "Nah",
                Callback = function()
                    plr:Kick("i bought a property in egypt")
                end 
            }
        }
    })
end
--boot

local Sections={
    ESP_Sec=Tabs.Visuals:AddSection("ESP")
}

local ESP_Toggle=Sections.ESP_Sec:AddToggle("Enabled", 
{
    Title = "Enabled", 
    Description = "Whether or not the ESP is enabled.",
    Default = true,
    Callback = function(state)
    if state then
        esp:Toggle(true)
    else
        esp:Toggle(false)
        end
    end 
})
local ESP_Names=Sections.ESP_Sec:AddToggle("Names", 
{
    Title = "Names", 
    Description = "Whether or not names should be shown.",
    Default = false,
    Callback = function(state)
    if state then
        esp.Names=true
    else
        esp.Names=false
        end
    end 
})
local ESP_Tracers=Sections.ESP_Sec:AddToggle("Tracers", 
{
    Title = "Tracers", 
    Description = "Whether or not tracers should be shown.",
    Default = false,
    Callback = function(state)
    if state then
        esp.Tracers=true
    else
        esp.Tracers=false
        end
    end 
})
local ESP_Color = Sections.ESP_Sec:AddColorpicker("Color", {
    Title = "Color",
    Description = "What color the esp should be.",
    Default = Color3.fromRGB(96, 205, 255)
})

ESP_Color:OnChanged(function()
    esp.Color=ESP_Color.Value
end)
    
ESP_Color:SetValueRGB(Color3.fromRGB(0, 255, 140))
Tabs.Tweaks:AddSlider("WalkSpeed", 
{
    Title = "Walk Speed",
    Description = "How fast the local player walks.",
    Default = 16,
    Min = 1,
    Max = 300,
    Rounding = 1,
    Callback = function(Value)
        plr.Character.Humanoid.WalkSpeed=Value
    end
})
Tabs.Tweaks:AddSlider("JumpPower", 
{
    Title = "Jump Power",
    Description = "How much the local players jump power is amplified.",
    Default = 50,
    Min = 1,
    Max = 300,
    Rounding = 1,
    Callback = function(Value)
        plr.Character.Humanoid.JumpPower=Value
    end
})
Tabs.Tweaks:AddSlider("Gravity", 
{
    Title = "Gravity",
    Description = "Default: 196",
    Default = 196,
    Min = 0,
    Max = 500,
    Rounding = 1,
    Callback = function(Value)
        game.Workspace.Gravity=Value
    end
})
Tabs.Tweaks:AddSlider("FOV", 
{
    Title = "FOV",
    Description = "Default: 70",
    Default = 70,
    Min = 40,
    Max = 120,
    Rounding = 1,
    Callback = function(Value)
        game.Workspace.CurrentCamera.FieldOfView=Value
    end
})
Tabs.Tweaks:AddToggle("DayNight", 
{
    Title = "Night Mode", 
    Description = "Whether or not the games time should be night.",
    Default = false,
    Callback = function(state)
    if state then
        game.Lighting.ClockTime=2.8
    else
        game.Lighting.ClockTime=ctime
        end
    end 
})
Tabs.Functions:AddButton({
    Title = "addfunc(n,v)",
    Description = "Allows the player to add custom functions.",
    Callback = function()
        add("addfunc",function(n : name,f : callback)
            getgenv[n]=f
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "zconsole_create()",
    Description = "If your executor doesnt support rconsole, this adds support.",
    Callback = function()
        add("zconsole_create",function()
            if not isfolder("zconsole") then
                makefolder("zconsole")
            end
            if not isfile("zconsole//PUT_ME_IN_THE_AUTOEXEC_FOLDER.luau") then
                writefile("zconsole//PUT_ME_IN_THE_AUTOEXEC_FOLDER.luau",[[
        local function postRequest(url, data)
                local response = request({
                    Url = "http://127.0.0.1:5000" .. url,
                    Method = "POST",
                    Headers = { ["Content-Type"] = "application/json" },
                    Body = game:GetService("HttpService"):JSONEncode(data)
                })
                
                if response.Success then
                    return game:GetService("HttpService"):JSONDecode(response.Body)
                else
                    warn("Request to " .. url .. " failed: " .. response.StatusMessage)
                    return nil
                end
            end
            
            getgenv().rconsoleprint = function(message, color, pattern)
                postRequest("/rconsoleprint", {message = message, color = color or "WHITE", pattern = pattern})
            end
            
            getgenv().rconsoleinfo = function(message)
                postRequest("/rconsoleinfo", {message = message})
            end
            
            getgenv().rconsolewarn = function(message)
                postRequest("/rconsolewarn", {message = message})
            end
            
            getgenv().rconsoleerr = function(message)
                postRequest("/rconsoleerr", {message = message})
            end
            
            getgenv().rconsoleclear = function()
                postRequest("/rconsoleclear", {})
            end
            
            getgenv().rconsolename = function(title)
                postRequest("/rconsolename", {title = title})
            end
            
            getgenv().rconsoleinput = function()
                local response = postRequest("/rconsoleinput", {})
                if response then
                    return response.input
                else
                    return nil
                end
            end
            
            getgenv().rconsolecreate = function()
                postRequest("/rconsolecreate", {})
            end
            
            getgenv().rconsoledestroy = function()
                postRequest("/rconsoledestroy", {})
            end 
                ]])
            end
            if not isfile("zconsole//client.txt") then
                writefile("zconsole//client.txt",[[
        
        # DONT RUN THIS IN ROBLOX, RUN THIS IN PYTHON.
        # INSTALL PYTHON IF YOU HAVENT
        # COPY AND PASTE THIS FILE AND SAVE IT AS A .PY FILE AND RUN IT. (or go to cloudconvert.com, and convert this file to a .py file and run it)
        # THEN YOU CAN USE ZCONSOLE.
        
        from flask import Flask, request, jsonify
        import threading
        import logging
        import os, re
        import ctypes
        
        app = Flask(__name__)
        
        colorCodes = {
            "BLACK": "\033[30m",
            "RED": "\033[31m",
            "GREEN": "\033[32m",
            "YELLOW": "\033[33m",
            "BLUE": "\033[34m",
            "MAGENTA": "\033[35m",
            "CYAN": "\033[36m",
            "WHITE": "\033[37m",
            "LIGHT_GRAY": "\033[37m",
            "DARK_GRAY": "\033[90m",
            "LIGHT_RED": "\033[91m",
            "LIGHT_GREEN": "\033[92m",
            "LIGHT_YELLOW": "\033[93m",
            "LIGHT_BLUE": "\033[94m",
            "LIGHT_MAGENTA": "\033[95m",
            "LIGHT_CYAN": "\033[96m",
            "ORANGE": "\033[38;5;208m",  # Adding orange color
            "RESET": "\033[0m"
        }
        
        def parseMessage(message, color):
            colorCode = colorCodes.get(color.upper(), colorCodes["WHITE"])
            return f"{colorCode}{message}{colorCodes['RESET']}"
        
        def printpattern(message, colors):
            pattern_message = ""
            color_cycle = [colorCodes[color.upper()] for color in colors if color.upper() in colorCodes]
            for i, char in enumerate(message):
                pattern_message += f"{color_cycle[i % len(color_cycle)]}{char}{colorCodes['RESET']}"
            return pattern_message
        
        @app.route('/rconsoleprint', methods=['POST'])
        def rconsolePrint():
            message = request.json.get('message', '')
            color = request.json.get('color', 'WHITE')
            pattern_colors = request.json.get('pattern', None)
            if pattern_colors:
                print(printpattern(message, pattern_colors))
            else:
                print(parseMessage(message, color))
            return jsonify(success=True)
        
        @app.route('/rconsoleclear', methods=['POST'])
        def rconsoleClear():
            os.system('cls' if os.name == 'nt' else 'clear')
            return jsonify(success=True)
        
        @app.route('/rconsolename', methods=['POST'])
        def rconsoleName():
            title = request.json.get('title', 'Console')
            os.system(f'title {title}')
            return jsonify(success=True)
        
        @app.route('/rconsoleinfo', methods=['POST'])
        def rconsoleInfo():
            message = request.json.get('message', '')
            print(parseMessage(message, 'CYAN'))
            return jsonify(success=True)
        
        @app.route('/rconsolewarn', methods=['POST'])
        def rconsoleWarn():
            message = request.json.get('message', '')
            print(parseMessage(message, 'YELLOW'))
            return jsonify(success=True)
        
        @app.route('/rconsoleerr', methods=['POST'])
        def rconsoleErr():
            message = request.json.get('message', '')
            print(parseMessage(message, 'RED'))
            return jsonify(success=True)
        
        @app.route('/rconsoleinput', methods=['POST'])
        def rconsoleInput():
            if isinstance(request.json, dict):
                prompt = request.json.get('prompt', '')
            else:
                prompt = ''
            user_input = input(parseMessage(prompt, 'WHITE'))
            return jsonify(input=user_input)
        
        @app.route('/rconsolecreate', methods=['POST'])
        def rconsoleCreate():
            # Add logic to create a console
            return jsonify(success=True)
        
        @app.route('/rconsoledestroy', methods=['POST'])
        def rconsoleDestroy():
            # Add logic to destroy a console
            return jsonify(success=True)
        
        log = logging.getLogger('werkzeug')
        log.setLevel(logging.ERROR)
        
        def set_console_always_on_top():
            HWND_TOPMOST = -1
            SWP_NOSIZE = 0x0001
            SWP_NOMOVE = 0x0002
            console_window = ctypes.windll.kernel32.GetConsoleWindow()
            ctypes.windll.user32.SetWindowPos(console_window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE)
        
        def runFlask():
            app.run(port=5000)
        
        if __name__ == '__main__':
            set_console_always_on_top()
            threading.Thread(target=runFlask).start()
            os.system('cls'); os.system('title zConsole')
        
                ]])
            end
            dbg("zConsole has been created. Go into your executors workspace folder, then you should see a folder named zconsole or something. Open it and follow the instruction in both of the files.")
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "setfov(n)",
    Description = "Allows change of the local players Field Of View.",
    Callback = function()
        add("setfov",function(n)
            game.Workspace.CurrentCamera.FieldOfView=n
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "zb1 encryption library",
    Description = "Adds zb1_encode(n) and zb1_decode(n)",
    Callback = function()
        add("zb1_encode", function(input, shift)
            local encoded = ""
            shift = shift or 3 -- Default shift is 3 if not provided
        
            for i = 1, #input do
                local char = input:sub(i, i)
                local byte = char:byte()
        
                -- Shift alphabetic characters (uppercase and lowercase)
                if byte >= 65 and byte <= 90 then
                    byte = ((byte - 65 + shift) % 26) + 65
                elseif byte >= 97 and byte <= 122 then
                    byte = ((byte - 97 + shift) % 26) + 97
                -- Shift numeric characters
                elseif byte >= 48 and byte <= 57 then
                    byte = ((byte - 48 + 4) % 10) + 48
                end
        
                encoded = encoded .. string.char(byte)
                -- Add random characters after each encoded character
                encoded = encoded .. randomChar() .. randomChar()
            end
        
            return encoded
        end)
        add("zb1_decode", function(input, shift)
            local decoded = ""
            shift = shift or 3
            local i = 1
        
            while i <= #input do
                local char = input:sub(i, i)
                local byte = char:byte()
        
                -- Shift alphabetic characters (uppercase and lowercase)
                if byte >= 65 and byte <= 90 then
                    byte = ((byte - 65 - shift + 26) % 26) + 65
                    decoded = decoded .. string.char(byte)
                elseif byte >= 97 and byte <= 122 then
                    byte = ((byte - 97 - shift + 26) % 26) + 97
                    decoded = decoded .. string.char(byte)
                -- Shift numeric characters
                elseif byte >= 48 and byte <= 57 then
                    byte = ((byte - 48 - 4 + 10) % 10) + 48
                    decoded = decoded .. string.char(byte)
                end
        
                -- Skip the next two random characters
                i = i + 3
            end
        
            return decoded
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "download_img(n)",
    Description = "Downloads an image from the web.",
    Callback = function()
        add("download_img", function(url, filename)
            if not isfolder("downloaded_images") then
                makefolder("downloaded_images")
            else
                return
            end
            print("Monarch - Getting image url...")
            local requestData = {
                Url = url,           -- The URL of the image
                Method = "GET",      -- GET request to download the image
                Headers = {          -- Optional headers (if needed)
                    ["User-Agent"] = "SynapseX"
                }
            }
        
            -- Make the request using syn.request
            local success, response = pcall(function()
                return syn.request(requestData)
            end)
        
            if success and response and response.Body then
                print("Monarch - Obtained URL "..url)
                -- The image data is stored in response.Body
                local imageData = response.Body
        
                -- Attempt to write the image data to the file
                local successWrite = pcall(function()
                    writefile("downloaded_images//"..filename, imageData)  -- Save to file
                end)
        
                if successWrite then
                    print("Monarch - Image saved as "..filename)
                else
                print("Monarch - Failed to save image.")
                end
        
            else
                local errorMessage = (response or "Unknown error")
                dbg("Failed to download image from URL: " ..errorMessage)
            end
        end) 
    end
})
Tabs.Functions:AddButton({
    Title = "checkrfe() + checkfe()",
    Description = "Checks if the game respects filtering enabled.",
    Callback = function()
        add("checkrfe", function(ss)
            local respectFilteringEnabledExists = pcall(function() return ss.RespectFilteringEnabled end)
        
            if not respectFilteringEnabledExists then
                print("Monarch - Error checking for RFE. | RespectFilteringEnabled is not a valid member of " .. ss.Name)
                return
            end
        
            if ss.RespectFilteringEnabled == false then
                print(ss.Name .. " does not respect filtering enabled. have fun exploiting it : )")
            else
                print(ss.Name .. " respects filtering enabled.")
            end
        
            local s, r = pcall(function()
                if ss.RespectFilteringEnabled == false then
                    print(ss.Name .. " does not respect filtering enabled. have fun exploiting it : )")
                else
                    print(ss.Name .. " respects filtering enabled.")
                end
            end)
        
            if not s then
                print("Monarch - Error checking for RFE. | " .. r)
            end
        end)
        add("checkfe", function(ss)
            local respectFilteringEnabledExists = pcall(function() return ss.FilteringEnabled end)
        
            if not respectFilteringEnabledExists then
                print("Monarch - Error checking for FE. | FilteringEnabled is not a valid member of " .. ss.Name)
                return
            end
        
            if ss.FilteringEnabled == false then
                print(ss.Name .. " does not have filtering enabled. have fun exploiting it : )")
                return false
            else
                print(ss.Name .. " has filtering enabled.")
                return true
            end
        
            local s, r = pcall(function()
                if ss.FilteringEnabled == false then
                    print(ss.Name .. " has filtering disabled. have fun exploiting it : )")
                else
                    print(ss.Name .. " has filtering enabled.")
                end
            end)
        
            if not s then
                print("Monarch - Error checking for RFE. | " .. r)
            end
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "debugscript(n)",
    Description = "Tests a script for any errors.",
    Callback = function()
        add("debugscript",function(source)
            local s, r = pcall(function()
                loadstring(source)()
            end)
            if s then
                print("Monarch - Script returned no errors.")
            else
                print("Monarch - Script returned error(s) | "..r)
            end
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "spoofexec()",
    Description = "Spoofs the executor name. This could break some scripts.",
    Callback = function()
        add("spoofexec",function(name)
            getgenv()["identifyexecutor"]=function()
                return name
            end
            getgenv()["getexecutorname"]=function()
                return name
            end
            getgenv()["getexecutor"]=function()
                return name
            end
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "killapiconnection()",
    Description = "basically roblox incognito mode (client side, just cuts api connection)",
    Callback = function()
        add("killapiconnection",function()
            game.Players.LocalPlayer.UserId=2
            game.Players.LocalPlayer.Name="John Doe"
            game.Players.LocalPlayer.DisplayName="John Doe"
            local char=game.Players.LocalPlayer.Character
            char.Head.Mesh.MeshId="https://assetdelivery.roblox.com/v1/asset/?id=18446596298"
            char.Head.Mesh.TextureId="rbxasset://textures/face.png"
        char["Body Colors"]:Destroy()
        char.Head.BrickColor=BrickColor.new("Daisy orange")
        char["Left Arm"].BrickColor=BrickColor.new("Daisy orange")
        char["Right Arm"].BrickColor=BrickColor.new("Daisy orange")
        char["Left Leg"].BrickColor=BrickColor.new("Medium blue")
        char["Right Leg"].BrickColor=BrickColor.new("Medium blue")
        char["Torso"].BrickColor=BrickColor.new("Bright yellow")
            for i,v in char:GetChildren() do
                if v:IsA("Accessory") or v:IsA("Shirt") or v:IsA("Pants") or v:IsA("T-Shirt") or v:IsA("Mesh") then
                    v:Destroy()
                end
            end
        end)
    end
})
Tabs.Functions:AddButton({
    Title = "runfromurl()",
    Description = "Runs a script from a url and returns any output.",
    Callback = function()
        add("runfromurl",function(v)
            loadstring(game:HttpGet(v))()
            return loadstring(game:HttpGet(v))()
        end)
    end
})
Tabs.Archive:AddButton({
    Title="Monarch Client V2",
    Description="Eh",
    Callback=function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/Exunys/Aimbot-V3/main/src/Aimbot.lua"))()
ExunysDeveloperAimbot()
ExunysDeveloperAimbot.Settings.Enabled=false
ExunysDeveloperAimbot.FOVSettings.Visible=false
local esp = loadstring(game:HttpGet("https://raw.githubusercontent.com/andrewc0de/Roblox/main/Dependencies/ESP.lua"))()
esp:Toggle(false)
esp.Color=Color3.fromRGB(132, 255, 169)
esp.Boxes = true
esp.Names = false
esp.Tracers = false
esp.Players = true
loadstring(game:HttpGet("https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/banwaveactive.lua"))()
local MacLib = loadstring(game:HttpGet("https://github.com/biggaboy212/Maclib/releases/latest/download/maclib.txt"))()
local Window = MacLib:Window({
    Title = "Monarch Client",
    Subtitle = "Free | V3",
    Size = UDim2.fromOffset(868, 650),
    DragStyle = 2,
    DisabledWindowControls = {},
    ShowUserInfo = true,
    Keybind = Enum.KeyCode.Home,
    AcrylicBlur = true,
})
local TabGroup = Window:TabGroup()
local Tab = TabGroup:Tab({
  Name="Aim",
  Image="rbxassetid://74298210297439"
})
local Tab2 = TabGroup:Tab({
  Name="Visuals",
  Image="rbxassetid://134394683265305"
})
local Section = Tab:Section({
  Side="Left"
})
local Section2 = Tab2:Section({
  Side="Left"
})
local Section3 = Tab:Section({
  Side="Right"
})
local Section4 = Tab:Section({
  Side="Left"
})
local Section5 = Tab2:Section({
  Side="Right"
})
Section:Toggle({
    Name="Aimbot",
    Default=false,
    Callback=function(t)
        if t==true then
            ExunysDeveloperAimbot.Settings.Enabled=true
        else
            ExunysDeveloperAimbot.Settings.Enabled=false
        end
    end
})
Section:Keybind({
    Name = "Keybind",
    onBinded = function(bind)
        ExunysDeveloperAimbot.Settings.TriggerKey=bind
        Window:Notify({
            Title = "Monarch Client",
            Description = "Set keybind to "..tostring(bind.Name),
            Lifetime = 3
        })
    end,
})
Section:Slider({
    Name="Field Of View",
    Default=90,
    Minimum=30,
    Maximum=180,
    DisplayMethod="Value",
    Callback=function(v)
        ExunysDeveloperAimbot.FOVSettings.Radius=v
    end
})
--t2
Section2:Header({
    Text="ESP"
})
Section2:Toggle({
    Name="Enabled",
    Default=false,
    Callback=function(t)
        if t==true then
            esp:Toggle(true)
        else
            esp:Toggle(false)
        end
    end
})
Section2:Toggle({
    Name="Tracers",
    Default=false,
    Callback=function(t)
        if t==true then
            esp.Tracers=true
        else
            esp.Tracers=false
        end
    end
})
Section2:Toggle({
    Name="Names",
    Default=false,
    Callback=function(t)
        if t==true then
            esp.Names=true
        else
            esp.Names=false
        end
    end
})
Section2:Colorpicker({
    Name = "Color",
    Default = Color3.fromRGB(132, 255, 169),
    Alpha = 0,
    Callback = function(C)
        esp.Color=C
    end,
})
Section3:Toggle({
    Name="Team Check",
    Default=false,
    Callback=function(t)
        if t==true then
            ExunysDeveloperAimbot.Settings.TeamCheck=true
        else
            ExunysDeveloperAimbot.Settings.TeamCheck=false
        end
    end
})
Section3:Toggle({
    Name="Alive Check",
    Default=false,
    Callback=function(t)
        if t==true then
            ExunysDeveloperAimbot.Settings.AliveCheck=true
        else
            ExunysDeveloperAimbot.Settings.AliveCheck=false
        end
    end
})
Section3:Toggle({
    Name="Wall Check",
    Default=false,
    Callback=function(t)
        if t==true then
            ExunysDeveloperAimbot.Settings.WallCheck=true
        else
            ExunysDeveloperAimbot.Settings.WallCheck=false
        end
    end
})
Section4:Dropdown({
    Name="Lock part",
    Search=true,
    Required=true,
    Options={
        "Head", "Torso", "Left Arm", "Right Arm", "Left Leg", "Right Leg"
    },
    Default=1,
    Callback=function(v)
        if v==1 then
            ExunysDeveloperAimbot.Settings.LockPart="Head"
        elseif v==2 then
            ExunysDeveloperAimbot.Settings.LockPart="Torso"
        elseif v==3 then
            ExunysDeveloperAimbot.Settings.LockPart="LeftArm"
        elseif v==4 then
            ExunysDeveloperAimbot.Settings.LockPart="RightArm"
        elseif v==5 then
            ExunysDeveloperAimbot.Settings.LockPart="LeftLeg"
        elseif v==6 then
            ExunysDeveloperAimbot.Settings.LockPart="RightLeg"
        end
    end
})
Section5:Header({
    Text="FOV"
})
Section5:Toggle({
    Name="Show FOV",
    Default=false,
    Callback=function(t)
        if t==true then
            ExunysDeveloperAimbot.FOVSettings.Visible=true
        else
            ExunysDeveloperAimbot.FOVSettings.Visible=false
        end
    end
})
Section5:Toggle({
    Name="Rainbow FOV",
    Default=false,
    Callback=function(t)
        if t==true then
            ExunysDeveloperAimbot.FOVSettings.RainbowColor=true
        else
            ExunysDeveloperAimbot.FOVSettings.RainbowColor=false
        end
    end
})
Section5:Colorpicker({
    Name = "Color",
    Default = Color3.fromRGB(255,255,255),
    Alpha = 0,
    Callback = function(C)
        ExunysDeveloperAimbot.FOVSettings.Color=C
    end,
})
Section5:Colorpicker({
    Name = "Locked Color",
    Default = Color3.fromRGB(255,150,150),
    Alpha = 0,
    Callback = function(C)
        ExunysDeveloperAimbot.FOVSettings.LockedColor=C
    end,
})
if banwaveactive==true then
    Window:Dialog({
    Title = "Monarch Client",
    Description = "Warning! Do NOT use this script on your main account or any account you do not want banned. Any executor claiming to be undetected, is detected.",
    Buttons = {
        {
            Name = "I'm on an alt."
        },
        {
            Name = "I'm on my main account.",
            Callback=function()
                Window:Notify({Title="Monarch Client",Description="Kicking local player in 5 seconds...",Lifetime=3})
                wait(3)
                Window:Unload()
                wait(2)
                game.Players.LocalPlayer:Kick("cuh")
            end
        }
    }
})
end
    end
})
Tabs.Scripts:AddButton({
    Title="Nameless admin",
    Description="Very useful admin script.",
    Callback=function()
        loadstring(game:HttpGet('https://raw.githubusercontent.com/FilteringEnabled/NamelessAdmin/main/Source'))()
    end
})
Tabs.Scripts:AddButton({
    Title="Dark Dex",
    Description="Allows uncontrolled exploration/change of the game.",
    Callback=function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/dex.lua"))()
    end
})
Tabs.Scripts:AddButton({
    Title="Infinite Yield",
    Description="Classic admin system. Very well made.",
    Callback=function()
        loadstring(game:HttpGet("https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/latest.lua"))()
    end
})
Tabs.Scripts:AddButton({
    Title="Glass",
    Description="Admin system made by me. Not many commands, but there will be more in the future.",
    Callback=function()
        -- imie his Gui to Lua
-- Version: 1
local Noclip = nil
local Clip = nil
function noclip()
    Clip = false
    local function Nocl()
        if Clip == false and game.Players.LocalPlayer.Character ~= nil then
            for _,v in pairs(game.Players.LocalPlayer.Character:GetDescendants()) do
                if v:IsA('BasePart') and v.CanCollide and v.Name ~= floatName then
                    v.CanCollide = false
                end
            end
        end
        wait(0.21) -- basic optimization
    end
    Noclip = game:GetService('RunService').Stepped:Connect(Nocl)
end

function clip()
    if Noclip then Noclip:Disconnect() end
    Clip = true
end
-- Instances:
local dof=Instance.new("DepthOfFieldEffect")
        dof.Enabled=true
        dof.Parent=game.Lighting
        dof.InFocusRadius=50
        dof.FocusDistance=60
        dof.FarIntensity=0.1
        dof.NearIntensity=1
local esp = loadstring(game:HttpGet("https://raw.githubusercontent.com/andrewc0de/Roblox/main/Dependencies/ESP.lua"))()
        esp:Toggle(false)
        esp.Boxes = true
        esp.Names = false
        esp.Tracers = false
        esp.Players = true
local glass = Instance.new("ScreenGui")
local main = Instance.new("Frame")
local mark = Instance.new("TextLabel")
local UICorner = Instance.new("UICorner")
local UIStroke = Instance.new("UIStroke")
local Shadow = Instance.new("ImageLabel")
local Frame = Instance.new("Frame")
local UICorner_2 = Instance.new("UICorner")
local TextBox = Instance.new("TextBox")
local notif = Instance.new("Frame")
local UICorner_3 = Instance.new("UICorner")
local UIStroke_2 = Instance.new("UIStroke")
local mark_2 = Instance.new("TextLabel")

--Properties:

glass.Name = "glass"
glass.Parent = game:WaitForChild("CoreGui")
glass.DisplayOrder = 100
glass.ResetOnSpawn = false

main.Name = "main"
main.Parent = glass
main.AnchorPoint = Vector2.new(0.5, 0.5)
main.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
main.BackgroundTransparency = 0.800
main.BorderColor3 = Color3.fromRGB(27, 42, 53)
main.BorderSizePixel = 0
main.Position = UDim2.new(0.5, 0, 0.5, 0)
main.Size = UDim2.new(0, 581, 0, 0)
main.ZIndex = 150

mark.Name = "mark"
mark.Parent = main
mark.AnchorPoint = Vector2.new(0.5, 0.5)
mark.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
mark.BackgroundTransparency = 1.000
mark.BorderColor3 = Color3.fromRGB(27, 42, 53)
mark.BorderSizePixel = 0
mark.Position = UDim2.new(0.503442347, 0, 1.15714288, 0)
mark.Size = UDim2.new(0, 277, 0, 18)
mark.ZIndex = 150
mark.FontFace = Font.new("rbxassetid://11702779517")
mark.Text = "Glass - Unofficial"
mark.TextColor3 = Color3.fromRGB(240, 240, 240)
mark.TextScaled = true
mark.TextSize = 14.000
mark.TextTransparency = 1.000
mark.TextWrapped = true

UICorner.CornerRadius = UDim.new(0, 13)
UICorner.Parent = main

UIStroke.Color = Color3.fromRGB(255, 255, 255)
UIStroke.Transparency = 1
UIStroke.Thickness = 1.2000000476837158
UIStroke.Parent = main

Shadow.Name = "Shadow"
Shadow.Parent = main
Shadow.AnchorPoint = Vector2.new(0.5, 0.5)
Shadow.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Shadow.BackgroundTransparency = 1.000
Shadow.BorderColor3 = Color3.fromRGB(27, 42, 53)
Shadow.BorderSizePixel = 0
Shadow.Position = UDim2.new(0.5, 0, 0.5, 0)
Shadow.Size = UDim2.new(1, 70, 1, 60)
Shadow.ZIndex = 149
Shadow.Image = "rbxassetid://3523728077"
Shadow.ImageColor3 = Color3.fromRGB(24, 24, 24)
Shadow.ImageTransparency = 1.000

Frame.Parent = main
Frame.AnchorPoint = Vector2.new(0.5, 0.5)
Frame.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
Frame.BackgroundTransparency = 1.000
Frame.BorderColor3 = Color3.fromRGB(0, 0, 0)
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.5, 0, 0.5, 0)
Frame.Size = UDim2.new(0.949999988, 0, 0.699999988, 0)

UICorner_2.CornerRadius = UDim.new(0, 13)
UICorner_2.Parent = Frame

TextBox.Parent = main
TextBox.AnchorPoint = Vector2.new(0.5, 0.5)
TextBox.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextBox.BackgroundTransparency = 1.000
TextBox.BorderColor3 = Color3.fromRGB(0, 0, 0)
TextBox.BorderSizePixel = 0
TextBox.Position = UDim2.new(0.5, 0, 0.5, 0)
TextBox.Size = UDim2.new(1, 0, 1, 0)
TextBox.ZIndex = 1500
TextBox.FontFace = Font.new("rbxassetid://11702779517", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
TextBox.PlaceholderColor3 = Color3.fromRGB(181, 181, 181)
TextBox.PlaceholderText = ";cmds"
TextBox.Text = ""
TextBox.TextColor3 = Color3.fromRGB(255, 255, 255)
TextBox.TextSize = 24.000
TextBox.TextTransparency = 1.000
TextBox.TextWrapped = true

notif.Name = "notif"
notif.Parent = glass
notif.AnchorPoint = Vector2.new(0.5, 0.5)
notif.BackgroundColor3 = Color3.fromRGB(25, 25, 25)
notif.BackgroundTransparency = 1.000
notif.BorderColor3 = Color3.fromRGB(0, 0, 0)
notif.BorderSizePixel = 0
notif.Position = UDim2.new(0.5, 0, 0.017651571, 0)
notif.Size = UDim2.new(0, 346, 0, 47)

UICorner_3.CornerRadius = UDim.new(0, 13)
UICorner_3.Parent = notif

UIStroke_2.Color = Color3.fromRGB(255, 255, 255)
UIStroke_2.Transparency = 1
UIStroke_2.Thickness = 1.2000000476837158
UIStroke_2.Parent = notif

mark_2.Name = "mark"
mark_2.Parent = notif
mark_2.AnchorPoint = Vector2.new(0.5, 0.5)
mark_2.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
mark_2.BackgroundTransparency = 1.000
mark_2.BorderColor3 = Color3.fromRGB(27, 42, 53)
mark_2.BorderSizePixel = 0
mark_2.Position = UDim2.new(0.497661978, 0, 0.497568339, 0)
mark_2.Size = UDim2.new(0, 277, 0, 18)
mark_2.ZIndex = 150
mark_2.FontFace = Font.new("rbxassetid://11702779517", Enum.FontWeight.Bold, Enum.FontStyle.Normal)
mark_2.Text = "Invalid Command"
mark_2.TextColor3 = Color3.fromRGB(240, 240, 240)
mark_2.TextScaled = true
mark_2.TextSize = 14.000
mark_2.TextTransparency = 1.000
mark_2.TextWrapped = true

-- Module Scripts:

local fake_module_scripts = {}

do -- Frame.bgblurmodule
    local script = Instance.new('ModuleScript', Frame)
    script.Name = "bgblurmodule"
    local function module_script()
        -- fractality
        
        
        local module = {}
        
        
        local RunService = game:GetService'RunService'
        local camera = workspace.CurrentCamera
        
        
        do
            local function IsNotNaN(x)
                return x == x
            end
            local continue = IsNotNaN(camera:ScreenPointToRay(0,0).Origin.x)
            while not continue do
                RunService.RenderStepped:wait()
                continue = IsNotNaN(camera:ScreenPointToRay(0,0).Origin.x)
            end
        end
        
        local binds = {}
        local root = Instance.new('Folder', camera)
        root.Name = 'neon'
        
        
        local GenUid; do -- Generate unique names for RenderStepped bindings
            local id = 0
            function GenUid()
                id = id + 1
                return 'neon::'..tostring(id)
            end
        end
        
        local DrawQuad; do
            local acos, max, pi, sqrt = math.acos, math.max, math.pi, math.sqrt
            local sz = 0.2
            
            function DrawTriangle(v1, v2, v3, p0, p1) -- I think Stravant wrote this function
                local s1 = (v1 - v2).magnitude
                local s2 = (v2 - v3).magnitude
                local s3 = (v3 - v1).magnitude
                local smax = max(s1, s2, s3)
                local A, B, C
                if s1 == smax then
                    A, B, C = v1, v2, v3
                elseif s2 == smax then
                    A, B, C = v2, v3, v1
                elseif s3 == smax then
                    A, B, C = v3, v1, v2
                end
            
                local para = ( (B-A).x*(C-A).x + (B-A).y*(C-A).y + (B-A).z*(C-A).z ) / (A-B).magnitude
                local perp = sqrt((C-A).magnitude^2 - para*para)
                local dif_para = (A - B).magnitude - para
            
                local st = CFrame.new(B, A)
                local za = CFrame.Angles(pi/2,0,0)
            
                local cf0 = st
            
                local Top_Look = (cf0 * za).lookVector
                local Mid_Point = A + CFrame.new(A, B).lookVector * para
                local Needed_Look = CFrame.new(Mid_Point, C).lookVector
                local dot = Top_Look.x*Needed_Look.x + Top_Look.y*Needed_Look.y + Top_Look.z*Needed_Look.z
            
                local ac = CFrame.Angles(0, 0, acos(dot))
            
                cf0 = cf0 * ac
                if ((cf0 * za).lookVector - Needed_Look).magnitude > 0.01 then
                    cf0 = cf0 * CFrame.Angles(0, 0, -2*acos(dot))
                end
                cf0 = cf0 * CFrame.new(0, perp/2, -(dif_para + para/2))
            
                local cf1 = st * ac * CFrame.Angles(0, pi, 0)
                if ((cf1 * za).lookVector - Needed_Look).magnitude > 0.01 then
                    cf1 = cf1 * CFrame.Angles(0, 0, 2*acos(dot))
                end
                cf1 = cf1 * CFrame.new(0, perp/2, dif_para/2)
            
                if not p0 then
                    p0 = Instance.new('Part')
                    p0.FormFactor = 'Custom'
                    p0.TopSurface = 0
                    p0.BottomSurface = 0
                    p0.Anchored = true
                    p0.CanCollide = false
                    p0.Material = 'Glass'
                    p0.Size = Vector3.new(sz, sz, sz)
                    local mesh = Instance.new('SpecialMesh', p0)
                    mesh.MeshType = 2
                    mesh.Name = 'WedgeMesh'
                end
                p0.WedgeMesh.Scale = Vector3.new(0, perp/sz, para/sz)
                p0.CFrame = cf0
                
                if not p1 then
                    p1 = p0:clone()
                end
                p1.WedgeMesh.Scale = Vector3.new(0, perp/sz, dif_para/sz)
                p1.CFrame = cf1
                
                return p0, p1
            end
        
            function DrawQuad(v1, v2, v3, v4, parts)
                parts[1], parts[2] = DrawTriangle(v1, v2, v3, parts[1], parts[2])
                parts[3], parts[4] = DrawTriangle(v3, v2, v4, parts[3], parts[4])
            end
        end
        
        
        --------------------------------
        ---- Module API --------------------------------
        ----------------------------------------------------------------
        
        
        -- Create a part binding for a GuiObject.
        function module:BindFrame(frame, properties)
            if binds[frame] then
                return binds[frame].parts
            end
            
            local uid = GenUid()
            local parts = {}
            local f = Instance.new('Folder', root)
            f.Name = frame.Name
            
            local parents = {} -- construct hierarchy tree for rotation
            do
                local function add(child)
                    if child:IsA'GuiObject' then
                        parents[#parents + 1] = child
                        add(child.Parent)
                    end
                end
                add(frame)
            end
            
            local function UpdateOrientation(fetchProps)
                local zIndex = 1 - 0.05*frame.ZIndex
                -- the transparency inversion bug still surfaces when there's z-fighting
                local tl, br = frame.AbsolutePosition, frame.AbsolutePosition + frame.AbsoluteSize
                local tr, bl = Vector2.new(br.x, tl.y), Vector2.new(tl.x, br.y)
                do
                    local rot = 0;
                    for _, v in ipairs(parents) do
                        rot = rot + v.Rotation
                    end
                    if rot ~= 0 and rot%180 ~= 0 then
                        local mid = tl:lerp(br, 0.5)
                        local s, c = math.sin(math.rad(rot)), math.cos(math.rad(rot))
                        local vec = tl
                        tl = Vector2.new(c*(tl.x - mid.x) - s*(tl.y - mid.y), s*(tl.x - mid.x) + c*(tl.y - mid.y)) + mid
                        tr = Vector2.new(c*(tr.x - mid.x) - s*(tr.y - mid.y), s*(tr.x - mid.x) + c*(tr.y - mid.y)) + mid
                        bl = Vector2.new(c*(bl.x - mid.x) - s*(bl.y - mid.y), s*(bl.x - mid.x) + c*(bl.y - mid.y)) + mid
                        br = Vector2.new(c*(br.x - mid.x) - s*(br.y - mid.y), s*(br.x - mid.x) + c*(br.y - mid.y)) + mid
                    end
                end
                DrawQuad(
                    camera:ScreenPointToRay(tl.x, tl.y, zIndex).Origin, 
                    camera:ScreenPointToRay(tr.x, tr.y, zIndex).Origin, 
                    camera:ScreenPointToRay(bl.x, bl.y, zIndex).Origin, 
                    camera:ScreenPointToRay(br.x, br.y, zIndex).Origin, 
                    parts
                )
                if fetchProps then
                    for _, pt in pairs(parts) do
                        pt.Parent = f
                    end
                    for propName, propValue in pairs(properties) do
                        for _, pt in pairs(parts) do
                            pt[propName] = propValue
                        end
                    end
                end
            end
        
            UpdateOrientation(true)
            RunService:BindToRenderStep(uid, 2000, UpdateOrientation)
            
            binds[frame] = {
                uid = uid;
                parts = parts;
            }
            return binds[frame].parts
        end
        
        -- Applies the `properties` table to bound parts.
        function module:Modify(frame, properties)
            local parts = module:GetBoundParts(frame)
            if parts then
                for propName, propValue in pairs(properties) do
                    for _, pt in pairs(parts) do
                        pt[propName] = propValue
                    end
                end
            else
                warn(('No part bindings exist for %s'):format(frame:GetFullName()))
            end
        end
        
        -- Removes the part binding from a gui object if one exists.
        function module:UnbindFrame(frame)
            local cb = binds[frame]
            if cb then
                RunService:UnbindFromRenderStep(cb.uid)
                for _, v in pairs(cb.parts) do
                    v:Destroy()
                end
                binds[frame] = nil
            else
                warn(('No part bindings exist for %s'):format(frame:GetFullName()))
            end
        end
        
        -- Returns true if a part binding exists for the gui object.
        function module:HasBinding(frame)
            return binds[frame] ~= nil
        end
        
        -- Returns an array using this.
        function module:GetBoundParts(frame)
            return binds[frame] and binds[frame].parts
        end
        
        
        return module
        
    end
    fake_module_scripts[script] = module_script
end


-- Scripts:

local function FRAIGTP_fake_script() -- Frame.bgblur 
    local script = Instance.new('LocalScript', Frame)
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

    require(script.Parent.bgblurmodule):BindFrame(script.Parent,{
        Transparency=.98,
        BrickColor=BrickColor.new("White")
    })
end
coroutine.wrap(FRAIGTP_fake_script)()
local function WPIBY_fake_script() -- main.fx 
    local script = Instance.new('LocalScript', main)
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

    local ts=game:FindFirstChildOfClass("TweenService")
    local uis=game:FindFirstChildOfClass("UserInputService")
    local lighting=game:FindFirstChildOfClass("Lighting")
    local plr=game:FindFirstChildOfClass("Players").LocalPlayer
    local wspeed=plr.Character:WaitForChild("Humanoid").WalkSpeed
    local cam=game.Workspace.CurrentCamera
    local fov=cam.FieldOfView
    local isopened=false
    local easingstyles={
        ["out"]=TweenInfo.new(.8,Enum.EasingStyle.Exponential,Enum.EasingDirection.Out),
        ["inout"]=TweenInfo.new(.5,Enum.EasingStyle.Quint,Enum.EasingDirection.InOut)
    }
    function open()
        script.Parent.TextBox:CaptureFocus()
        script.Parent.TextBox.TextSize=14
        ts:Create(cam,easingstyles.out,{FieldOfView=fov-40}):Play()
        cam.CameraType=Enum.CameraType.Scriptable
        plr.Character:WaitForChild("Humanoid").WalkSpeed=0
        ts:Create(script.Parent.TextBox,easingstyles.out,{TextSize=24}):Play()
        ts:Create(script.Parent.mark,easingstyles.out,{TextTransparency=.6}):Play()
        ts:Create(script.Parent,easingstyles.out,{Size=UDim2.new(0,581,0,70)}):Play()
        ts:Create(script.Parent.UIStroke,easingstyles.out,{Transparency=.95}):Play()
        ts:Create(script.Parent.Shadow,easingstyles.out,{ImageTransparency=.7}):Play()
        ts:Create(lighting.DepthOfField,easingstyles.out,{NearIntensity=6}):Play()
        ts:Create(script.Parent.TextBox,easingstyles.out,{TextTransparency=.3}):Play()
    end
    function close()
        ts:Create(script.Parent.TextBox,easingstyles.out,{TextSize=14}):Play()
        ts:Create(cam,easingstyles.out,{FieldOfView=fov}):Play()
        cam.CameraType=Enum.CameraType.Custom
        plr.Character:WaitForChild("Humanoid").WalkSpeed=wspeed
        ts:Create(script.Parent.mark,easingstyles.out,{TextTransparency=1}):Play()
        ts:Create(script.Parent.TextBox,easingstyles.out,{TextTransparency=1}):Play()
        ts:Create(script.Parent,easingstyles.out,{Size=UDim2.new(0,581,0,0)}):Play()
        ts:Create(script.Parent.UIStroke,easingstyles.out,{Transparency=1}):Play()
        ts:Create(script.Parent.Shadow,easingstyles.out,{ImageTransparency=1}):Play()
        ts:Create(lighting.DepthOfField,easingstyles.out,{NearIntensity=0}):Play()
        ts:Create(script.Parent.TextBox,easingstyles.out,{TextTransparency=1}):Play()
    end
    uis.InputBegan:Connect(function(inp,proc)
        if proc==true then return end
        if inp.KeyCode==Enum.KeyCode.Semicolon then
            open()
            script.Parent.TextBox.FocusLost:Connect(function()
                close()
            end)
        end
    end)
end
coroutine.wrap(WPIBY_fake_script)()
local function XDTY_fake_script() -- main.core 
    local script = Instance.new('LocalScript', main)
    local req = require
    local require = function(obj)
        local fake = fake_module_scripts[obj]
        if fake then
            return fake()
        end
        return req(obj)
    end

    local ReplicatedStorage = game:GetService("ReplicatedStorage")
    local Players = game:GetService("Players")
    local ts = game:FindFirstChildOfClass("TweenService")
    local uis = game:GetService("UserInputService")
    local cam = game.Workspace.CurrentCamera
    local fov = cam.FieldOfView
    
    local plr = Players.LocalPlayer
    local easingstyles = {
        ["out"] = TweenInfo.new(0.8, Enum.EasingStyle.Exponential, Enum.EasingDirection.Out),
        ["inout"] = TweenInfo.new(0.8, Enum.EasingStyle.Quint, Enum.EasingDirection.InOut)
    }
    
    local currenttheme="glass"

    local commands = {}
    
    function addcmd(cmd, func)
        commands[cmd] = func
    end
    
    local function notify(txt)
        local parent = script.Parent.Parent
        parent.notif.mark.Text = txt
        parent.notif.Position = UDim2.new(0.5, 0, 0.035, 0)
        ts:Create(parent.notif, easingstyles.out, {Position = UDim2.new(0.5, 0, 0.025, 0), BackgroundTransparency = 0.8}):Play()
        ts:Create(parent.notif.UIStroke, easingstyles.out, {Transparency = 0.95}):Play()
        ts:Create(parent.notif.mark, easingstyles.inout, {TextTransparency = 0.3}):Play()
        task.wait(2)
        ts:Create(parent.notif, easingstyles.inout, {Position = UDim2.new(0.5, 0, 0.018, 0), BackgroundTransparency = 1}):Play()
        ts:Create(parent.notif.UIStroke, easingstyles.inout, {Transparency = 1}):Play()
        ts:Create(parent.notif.mark, easingstyles.inout, {TextTransparency = 1}):Play()
    end
    
    addcmd("test", function(args)
        notify("Test command executed")
    end)
    
    addcmd("theme",function()
        notify("Current theme: '"..currenttheme.."'")
    end)

    addcmd("theme/load", function(args)
        local function loadtheme(bgcolor,TextColor,strokecolor)
            script.Parent.BackgroundColor3=bgcolor
            script.Parent.UIStroke.Color=strokecolor
            script.Parent.Parent.notif.UIStroke.Color=strokecolor
            script.Parent.Parent.notif.BackgroundColor3=bgcolor
            script.Parent.TextBox.TextColor3=TextColor
            script.Parent.mark.TextColor3=TextColor
            script.Parent.Parent.notif.mark.TextColor3=TextColor
        end
        if args[1] then
            if args[1]=="nord" then
                currenttheme="nord"
                loadtheme(Color3.fromRGB(46, 52, 64),Color3.fromRGB(216, 222, 233),Color3.new(1,1,1))
            elseif args[1]=="crimson" then
                currenttheme="crimson"
                loadtheme(Color3.fromRGB(64, 18, 18),Color3.fromRGB(0,0,0),Color3.fromRGB(0,0,0))
            elseif args[1]=="glass" then
                currenttheme="glass"
                loadtheme(Color3.fromRGB(25, 25, 25),Color3.new(1,1,1),Color3.new(1,1,1))
            elseif args[1]=="mint" then
                currenttheme="mint"
                loadtheme(Color3.fromRGB(194, 255, 166),Color3.new(1,1,1),Color3.new(1,1,1))
            elseif args[1]=="chroma" then
                currenttheme="chroma"
                loadtheme(Color3.fromRGB(150, 80, 255),Color3.fromRGB(0,0,0),Color3.fromRGB(0,0,0))
            elseif args[1]=="terminal" then
                currenttheme="terminal"
                loadtheme(Color3.fromRGB(0,0,0),Color3.fromRGB(0,255,0),Color3.fromRGB(0,255,0))
            elseif args[1]=="bnw" then
                currenttheme="bnw"
                loadtheme(Color3.fromRGB(0, 0, 0),Color3.fromRGB(255,255,255),Color3.fromRGB(255,255,255))
            end
        else
            notify("Invalid Theme Value. (Type a theme name after theme/load)")
        end
    end)
    
    addcmd("notify", function(args)
        notify(table.concat(args, " "))
    end)
    
    addcmd("walkspeed", function(args)
        local speed = tonumber(args[1])
        if speed then
            plr.Character.Humanoid.WalkSpeed = speed
            notify("Walk speed set to " .. speed)
        else
            notify("Invalid walk speed value")
        end
    end)
    addcmd("wspeed", function(args)
        local speed = tonumber(args[1])
        if speed then
            plr.Character.Humanoid.WalkSpeed = speed
            notify("Walk speed set to " .. speed)
        else
            notify("Invalid walk speed value")
        end
    end)
    addcmd("ws", function(args)
        local speed = tonumber(args[1])
        if speed then
            plr.Character.Humanoid.WalkSpeed = speed
            notify("Walk speed set to " .. speed)
        else
            notify("Invalid walk speed value")
        end
    end)
    
    addcmd("jumppower", function(args)
        local power = tonumber(args[1])
        if power then
            plr.Character.Humanoid.JumpPower = power
            notify("Jump power set to " .. power)
        else
            notify("Invalid jump power value")
        end
    end)
    addcmd("jpower", function(args)
        local power = tonumber(args[1])
        if power then
            plr.Character.Humanoid.JumpPower = power
            notify("Jump power set to " .. power)
        else
            notify("Invalid jump power value")
        end
    end)
    addcmd("jp", function(args)
        local power = tonumber(args[1])
        if power then
            plr.Character.Humanoid.JumpPower = power
            notify("Jump power set to " .. power)
        else
            notify("Invalid jump power value")
        end
    end)
    addcmd("tp", function(args)
        local targetPlayerName = args[1]
        if targetPlayerName then
            local targetPlayer = game.Players:FindFirstChild(targetPlayerName)
            if targetPlayer and targetPlayer.Character and targetPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local targetHumanoidRootPart = targetPlayer.Character.HumanoidRootPart
                if plr.Character and plr.Character:FindFirstChild("HumanoidRootPart") then
                    local humanoidRootPart = plr.Character.HumanoidRootPart
                    humanoidRootPart.CFrame = targetHumanoidRootPart.CFrame
                    notify("Teleported to " .. targetPlayerName)
                else
                    notify("Your HumanoidRootPart not found")
                end
            else
                notify("Target player or their HumanoidRootPart not found")
            end
        else
            notify("Please specify a player to teleport to")
        end
    end)
    addcmd("goto", function(args)
        local targetPlayerName = args[1]
        if targetPlayerName then
            local targetPlayer = game.Players:FindFirstChild(targetPlayerName)
            if targetPlayer and targetPlayer.Character and targetPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local targetHumanoidRootPart = targetPlayer.Character.HumanoidRootPart
                if plr.Character and plr.Character:FindFirstChild("HumanoidRootPart") then
                    local humanoidRootPart = plr.Character.HumanoidRootPart
                    humanoidRootPart.CFrame = targetHumanoidRootPart.CFrame
                    notify("Teleported to " .. targetPlayerName)
                else
                    notify("Your HumanoidRootPart not found")
                end
            else
                notify("Target player or their HumanoidRootPart not found")
            end
        else
            notify("Please specify a player to teleport to")
        end
    end)
    addcmd("teleport", function(args)
        local targetPlayerName = args[1]
        if targetPlayerName then
            local targetPlayer = game.Players:FindFirstChild(targetPlayerName)
            if targetPlayer and targetPlayer.Character and targetPlayer.Character:FindFirstChild("HumanoidRootPart") then
                local targetHumanoidRootPart = targetPlayer.Character.HumanoidRootPart
                if plr.Character and plr.Character:FindFirstChild("HumanoidRootPart") then
                    local humanoidRootPart = plr.Character.HumanoidRootPart
                    humanoidRootPart.CFrame = targetHumanoidRootPart.CFrame
                    notify("Teleported to " .. targetPlayerName)
                else
                    notify("Your HumanoidRootPart not found")
                end
            else
                notify("Target player or their HumanoidRootPart not found")
            end
        else
            notify("Please specify a player to teleport to")
        end
    end)
    addcmd("fov", function(args)
        if args[1] then
            notify("one sec...")
            wait(2)
            ts:Create(cam,easingstyles.out,{FieldOfView=tonumber(args[1])}):Play()
            wait(.8)
            if cam.FieldOfView==tonumber(args[1]) then
                fov=tonumber(args[1])
                notify("FOV set to " .. tonumber(args[1]))
            else
                notify("Failed to set fov")
            end
        else
            notify("Invalid FOV value")
        end
    end)
    addcmd("antifling",function()
        noclip()
    end)
    addcmd("noclip",function()
        noclip()
    end)
    addcmd("clip",function()
        clip()
    end)
    addcmd("unantifling",function()
        clip()
    end)
    addcmd("esp",function(args)
        if args[1] then
            if args[1]=="on" or args[1]=="true" or args[1]=="enabled" or args[1]=="enable" then
                esp:Toggle(true)
            else
                esp:Toggle(false)
            end
        else
            notify("Invalid Bool Value (Type on or off after esp)")
        end
    end)
    addcmd("esp/tracers", function(args)
        if args[1] then
            if args[1]=="on" or args[1]=="true" or args[1]=="enabled" or args[1]=="enable" then
                esp.Tracers = true
            else
                esp.Tracers = false
            end
        else
            notify("Invalid Bool Value (Type on or off after esp/tracers)")
        end
    end)
    addcmd("dex",function()
        notify("Loading dex. (requires decompiler to view scripts)")
        loadstring(game:HttpGet("https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/dex.lua", true))()
    end)
    addcmd("explorer",function()
        notify("Loading dex. (requires decompiler to view scripts)")
        loadstring(game:HttpGet("https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/dex.lua", true))()
    end)
    addcmd("ddex",function()
        notify("Loading dex. (requires decompiler to view scripts)")
        loadstring(game:HttpGet("https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/dex.lua", true))()
    end)
    addcmd("darkdex",function()
        notify("Loading dex. (requires decompiler to view scripts)")
        loadstring(game:HttpGet("https://raw.githubusercontent.com/DarkNetworks/Infinite-Yield/refs/heads/main/dex.lua", true))()
    end)
    addcmd("esp/names", function(args)
        if args[1] then
            if args[1]=="on" or args[1]=="true" or args[1]=="enabled" or args[1]=="enable" then
                esp.Names = true
            else
                esp.Names = false
            end
        else
            notify("Invalid Bool Value (Type on or off after esp/names)")
        end
    end)
    addcmd("cmds",function()
        notify("https://glass-2.gitbook.io/glass-docs")
    end)
    addcmd("commands",function()
        notify("https://glass-2.gitbook.io/glass-docs")
    end)
    addcmd("docs",function()
        notify("https://glass-2.gitbook.io/glass-docs")
    end)
    addcmd("documentation",function()
        notify("https://glass-2.gitbook.io/glass-docs")
    end)
    addcmd("exit",function()
        script.Parent.Parent:Destroy()
    end)
    addcmd("close",function()
        script.Parent.Parent:Destroy()
    end)
    addcmd("destroy",function()
        script.Parent.Parent:Destroy()
    end)
    
    function getcmd()
        local cmdText = script.Parent.TextBox.Text
        local splitText = cmdText:split(" ")
        local cmd = splitText[1]:sub(2)
        local args = {unpack(splitText, 2)} 
        if commands[cmd] then
            commands[cmd](args)
        else
            notify("Command not recognized")
        end
    end
    
    -- Capture the command from the TextBox when the player presses Enter
    script.Parent.TextBox.FocusLost:Connect(function(enterPressed)
        if enterPressed then
            getcmd()
        end
    end)
    
end
coroutine.wrap(XDTY_fake_script)()

    end
})
Window:SelectTab(1)