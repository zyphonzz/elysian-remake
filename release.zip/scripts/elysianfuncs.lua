getgenv().identifyexecutor=function()
    return "Elysian"
end
local s  = Instance.new("StringValue")
s.Parent = game.ReplicatedStorage
s.Value  = "fQluytwQE3ip2sf8FWhJwuRPf5t1Ga2cwyr9iYilK1xjB7UK8cG_ELYSIAN_8eU9vwubsiZwy8mqlx2zH1CO"
wait(2)
if identifyexecutor()=="Elysian" then
    print("Elysian Valid.")
else
    game.Players.LocalPlayer:Kick("Elysian crack detected.")
end
if game.ReplicatedStorage:FindFirstChildOfClass("StringValue").Value=="fQluytwQE3ip2sf8FWhJwuRPf5t1Ga2cwyr9iYilK1xjB7UK8cG_ELYSIAN_8eU9vwubsiZwy8mqlx2zH1CO" then
    print("Elysian Token Valid")
else
    game.Players.LocalPlayer:Kick("Invalid Elysian Token.")
end

--adds a func to the global env
local function add(n : string,v : func)
    getgenv()[n]=v
    print("Elysian - Added "..n.." to the global environment.")
end
--removes a func from the global env
local function remove(n : string)
    getgenv()[n]=nil
    print("Elysian - Removed "..n.." from the global environment.")
end
--generates a random character
local function randomChar()
    local chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local randIndex = math.random(1, #chars)
    return chars:sub(randIndex, randIndex)
end
--debugs a message
function dbg(n)
    print("Elysian - "..n)
end
--// global \\--
add("addfunc",function(n : name,f : callback)
    getgenv[n]=f
end)
add("zconsole_create",function()
    if not isfolder("zconsole") then
        makefolder("zconsole")
    end
    if not isfile("zconsole//PUT_ME_IN_THE_AUTOEXEC_FOLDER.luau") then
        writefile("zconsole//PUT_ME_IN_THE_AUTOEXEC_FOLDER.luau",[[
local function postRequest(url, data)
        local response = request({
            Url = "http://127.0.0.1:5000" .. url,
            Method = "POST",
            Headers = { ["Content-Type"] = "application/json" },
            Body = game:GetService("HttpService"):JSONEncode(data)
        })
        
        if response.Success then
            return game:GetService("HttpService"):JSONDecode(response.Body)
        else
            warn("Request to " .. url .. " failed: " .. response.StatusMessage)
            return nil
        end
    end
    
    getgenv().rconsoleprint = function(message, color, pattern)
        postRequest("/rconsoleprint", {message = message, color = color or "WHITE", pattern = pattern})
    end
    
    getgenv().rconsoleinfo = function(message)
        postRequest("/rconsoleinfo", {message = message})
    end
    
    getgenv().rconsolewarn = function(message)
        postRequest("/rconsolewarn", {message = message})
    end
    
    getgenv().rconsoleerr = function(message)
        postRequest("/rconsoleerr", {message = message})
    end
    
    getgenv().rconsoleclear = function()
        postRequest("/rconsoleclear", {})
    end
    
    getgenv().rconsolename = function(title)
        postRequest("/rconsolename", {title = title})
    end
    
    getgenv().rconsoleinput = function()
        local response = postRequest("/rconsoleinput", {})
        if response then
            return response.input
        else
            return nil
        end
    end
    
    getgenv().rconsolecreate = function()
        postRequest("/rconsolecreate", {})
    end
    
    getgenv().rconsoledestroy = function()
        postRequest("/rconsoledestroy", {})
    end 
        ]])
    end
    if not isfile("zconsole//client.txt") then
        writefile("zconsole//client.txt",[[

# DONT RUN THIS IN ROBLOX, RUN THIS IN PYTHON.
# INSTALL PYTHON IF YOU HAVENT
# COPY AND PASTE THIS FILE AND SAVE IT AS A .PY FILE AND RUN IT. (or go to cloudconvert.com, and convert this file to a .py file and run it)
# THEN YOU CAN USE ZCONSOLE.

from flask import Flask, request, jsonify
import threading
import logging
import os, re
import ctypes

app = Flask(__name__)

colorCodes = {
    "BLACK": "\033[30m",
    "RED": "\033[31m",
    "GREEN": "\033[32m",
    "YELLOW": "\033[33m",
    "BLUE": "\033[34m",
    "MAGENTA": "\033[35m",
    "CYAN": "\033[36m",
    "WHITE": "\033[37m",
    "LIGHT_GRAY": "\033[37m",
    "DARK_GRAY": "\033[90m",
    "LIGHT_RED": "\033[91m",
    "LIGHT_GREEN": "\033[92m",
    "LIGHT_YELLOW": "\033[93m",
    "LIGHT_BLUE": "\033[94m",
    "LIGHT_MAGENTA": "\033[95m",
    "LIGHT_CYAN": "\033[96m",
    "ORANGE": "\033[38;5;208m",  # Adding orange color
    "RESET": "\033[0m"
}

def parseMessage(message, color):
    colorCode = colorCodes.get(color.upper(), colorCodes["WHITE"])
    return f"{colorCode}{message}{colorCodes['RESET']}"

def printpattern(message, colors):
    pattern_message = ""
    color_cycle = [colorCodes[color.upper()] for color in colors if color.upper() in colorCodes]
    for i, char in enumerate(message):
        pattern_message += f"{color_cycle[i % len(color_cycle)]}{char}{colorCodes['RESET']}"
    return pattern_message

@app.route('/rconsoleprint', methods=['POST'])
def rconsolePrint():
    message = request.json.get('message', '')
    color = request.json.get('color', 'WHITE')
    pattern_colors = request.json.get('pattern', None)
    if pattern_colors:
        print(printpattern(message, pattern_colors))
    else:
        print(parseMessage(message, color))
    return jsonify(success=True)

@app.route('/rconsoleclear', methods=['POST'])
def rconsoleClear():
    os.system('cls' if os.name == 'nt' else 'clear')
    return jsonify(success=True)

@app.route('/rconsolename', methods=['POST'])
def rconsoleName():
    title = request.json.get('title', 'Console')
    os.system(f'title {title}')
    return jsonify(success=True)

@app.route('/rconsoleinfo', methods=['POST'])
def rconsoleInfo():
    message = request.json.get('message', '')
    print(parseMessage(message, 'CYAN'))
    return jsonify(success=True)

@app.route('/rconsolewarn', methods=['POST'])
def rconsoleWarn():
    message = request.json.get('message', '')
    print(parseMessage(message, 'YELLOW'))
    return jsonify(success=True)

@app.route('/rconsoleerr', methods=['POST'])
def rconsoleErr():
    message = request.json.get('message', '')
    print(parseMessage(message, 'RED'))
    return jsonify(success=True)

@app.route('/rconsoleinput', methods=['POST'])
def rconsoleInput():
    if isinstance(request.json, dict):
        prompt = request.json.get('prompt', '')
    else:
        prompt = ''
    user_input = input(parseMessage(prompt, 'WHITE'))
    return jsonify(input=user_input)

@app.route('/rconsolecreate', methods=['POST'])
def rconsoleCreate():
    # Add logic to create a console
    return jsonify(success=True)

@app.route('/rconsoledestroy', methods=['POST'])
def rconsoleDestroy():
    # Add logic to destroy a console
    return jsonify(success=True)

log = logging.getLogger('werkzeug')
log.setLevel(logging.ERROR)

def set_console_always_on_top():
    HWND_TOPMOST = -1
    SWP_NOSIZE = 0x0001
    SWP_NOMOVE = 0x0002
    console_window = ctypes.windll.kernel32.GetConsoleWindow()
    ctypes.windll.user32.SetWindowPos(console_window, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE)

def runFlask():
    app.run(port=5000)

if __name__ == '__main__':
    set_console_always_on_top()
    threading.Thread(target=runFlask).start()
    os.system('cls'); os.system('title zConsole')

        ]])
    end
    dbg("zConsole has been created. Go into your executors workspace folder, then you should see a folder named zconsole or something. Open it and follow the instruction in both of the files.")
end)
add("setfov",function(n)
    game.Workspace.CurrentCamera.FieldOfView=n
end)
add("zb1_encode", function(input, shift)
    local encoded = ""
    shift = shift or 3 -- Default shift is 3 if not provided

    for i = 1, #input do
        local char = input:sub(i, i)
        local byte = char:byte()

        -- Shift alphabetic characters (uppercase and lowercase)
        if byte >= 65 and byte <= 90 then
            byte = ((byte - 65 + shift) % 26) + 65
        elseif byte >= 97 and byte <= 122 then
            byte = ((byte - 97 + shift) % 26) + 97
        -- Shift numeric characters
        elseif byte >= 48 and byte <= 57 then
            byte = ((byte - 48 + 4) % 10) + 48
        end

        encoded = encoded .. string.char(byte)
        -- Add random characters after each encoded character
        encoded = encoded .. randomChar() .. randomChar()
    end

    return encoded
end)

add("zb1_decode", function(input, shift)
    local decoded = ""
    shift = shift or 3
    local i = 1

    while i <= #input do
        local char = input:sub(i, i)
        local byte = char:byte()

        -- Shift alphabetic characters (uppercase and lowercase)
        if byte >= 65 and byte <= 90 then
            byte = ((byte - 65 - shift + 26) % 26) + 65
            decoded = decoded .. string.char(byte)
        elseif byte >= 97 and byte <= 122 then
            byte = ((byte - 97 - shift + 26) % 26) + 97
            decoded = decoded .. string.char(byte)
        -- Shift numeric characters
        elseif byte >= 48 and byte <= 57 then
            byte = ((byte - 48 - 4 + 10) % 10) + 48
            decoded = decoded .. string.char(byte)
        end

        -- Skip the next two random characters
        i = i + 3
    end

    return decoded
end)
add("download_img", function(url, filename)
    if not isfolder("downloaded_images") then
        makefolder("downloaded_images")
    else
        return
    end
    print("Elysian - Getting image url...")
    local requestData = {
        Url = url,           -- The URL of the image
        Method = "GET",      -- GET request to download the image
        Headers = {          -- Optional headers (if needed)
            ["User-Agent"] = "SynapseX"
        }
    }

    -- Make the request using syn.request
    local success, response = pcall(function()
        return syn.request(requestData)
    end)

    if success and response and response.Body then
        print("Elysian - Obtained URL "..url)
        -- The image data is stored in response.Body
        local imageData = response.Body

        -- Attempt to write the image data to the file
        local successWrite = pcall(function()
            writefile("downloaded_images//"..filename, imageData)  -- Save to file
        end)

        if successWrite then
            print("Elysian - Image saved as "..filename)
        else
        print("Elysian - Failed to save image.")
        end

    else
        local errorMessage = (response or "Unknown error")
        dbg("Failed to download image from URL: " ..errorMessage)
    end
end) 
add("checkrfe", function(ss)
    local respectFilteringEnabledExists = pcall(function() return ss.RespectFilteringEnabled end)

    if not respectFilteringEnabledExists then
        print("Elysian - Error checking for RFE. | RespectFilteringEnabled is not a valid member of " .. ss.Name)
        return
    end

    if ss.RespectFilteringEnabled == false then
        print(ss.Name .. " does not respect filtering enabled. have fun exploiting it : )")
    else
        print(ss.Name .. " respects filtering enabled.")
    end

    local s, r = pcall(function()
        if ss.RespectFilteringEnabled == false then
            print(ss.Name .. " does not respect filtering enabled. have fun exploiting it : )")
        else
            print(ss.Name .. " respects filtering enabled.")
        end
    end)

    if not s then
        print("Elysian - Error checking for RFE. | " .. r)
    end
end)
add("checkfe", function(ss)
    local respectFilteringEnabledExists = pcall(function() return ss.FilteringEnabled end)

    if not respectFilteringEnabledExists then
        print("Elysian - Error checking for FE. | FilteringEnabled is not a valid member of " .. ss.Name)
        return
    end

    if ss.FilteringEnabled == false then
        print(ss.Name .. " does not have filtering enabled. have fun exploiting it : )")
        return false
    else
        print(ss.Name .. " has filtering enabled.")
        return true
    end

    local s, r = pcall(function()
        if ss.FilteringEnabled == false then
            print(ss.Name .. " has filtering disabled. have fun exploiting it : )")
        else
            print(ss.Name .. " has filtering enabled.")
        end
    end)

    if not s then
        print("Elysian - Error checking for RFE. | " .. r)
    end
end)
add("debugscript",function(source)
    local s, r = pcall(function()
        loadstring(source)()
    end)
    if s then
        print("Elysian - Script returned no errors.")
    else
        print("Elysian - Script returned error(s) | "..r)
    end
end)
add("spoofexec",function(name)
    getgenv()["identifyexecutor"]=function()
        return name
    end
    getgenv()["getexecutorname"]=function()
        return name
    end
    getgenv()["getexecutor"]=function()
        return name
    end
end)
add("killapiconnection",function()
    game.Players.LocalPlayer.UserId=2
    game.Players.LocalPlayer.Name="John Doe"
    game.Players.LocalPlayer.DisplayName="John Doe"
    local char=game.Players.LocalPlayer.Character
    char.Head.Mesh.MeshId="https://assetdelivery.roblox.com/v1/asset/?id=18446596298"
    char.Head.Mesh.TextureId="rbxasset://textures/face.png"
char["Body Colors"]:Destroy()
char.Head.BrickColor=BrickColor.new("Daisy orange")
char["Left Arm"].BrickColor=BrickColor.new("Daisy orange")
char["Right Arm"].BrickColor=BrickColor.new("Daisy orange")
char["Left Leg"].BrickColor=BrickColor.new("Medium blue")
char["Right Leg"].BrickColor=BrickColor.new("Medium blue")
char["Torso"].BrickColor=BrickColor.new("Bright yellow")
    for i,v in char:GetChildren() do
        if v:IsA("Accessory") or v:IsA("Shirt") or v:IsA("Pants") or v:IsA("T-Shirt") or v:IsA("Mesh") then
            v:Destroy()
        end
    end
end)
add("runfromurl",function(v)
    loadstring(game:HttpGet(v))()
    return loadstring(game:HttpGet(v))()
end)