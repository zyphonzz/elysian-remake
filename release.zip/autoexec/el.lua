getgenv().identifyexecutor=function()
	return "Elysian"
end
local s  = Instance.new("StringValue")
s.Parent = game.ReplicatedStorage
s.Value  = "fQluytwQE3ip2sf8FWhJwuRPf5t1Ga2cwyr9iYilK1xjB7UK8cG_ELYSIAN_8eU9vwubsiZwy8mqlx2zH1CO"