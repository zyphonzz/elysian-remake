﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using cxapi;
using System.Net.Http;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace ProjectLigmaRealTrust
{
    public partial class Form1 : Form
    {
        private Point mouseDownPoint = Point.Empty;
        private Point targetLocation = Point.Empty;
        private Timer moveTimer = new Timer();
        private FileSystemWatcher watcher;

        public Form1()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
            this.SetStyle(ControlStyles.ResizeRedraw, true);

            moveTimer.Interval = 10;
            moveTimer.Tick += MoveTimer_Tick;

            listBox1.SelectedIndexChanged += ListBox1_SelectedIndexChanged; // Ensure this event is hooked up

            // Initialize FileSystemWatcher
            InitializeFileSystemWatcher();

            // Check for active ban wave
            CheckBanWave();
        }

        private async void CheckBanWave()
        {
            string url = "https://raw.githubusercontent.com/zyphonzz/Monarch-Client/refs/heads/main/banwaveactive.lua";
            using (HttpClient client = new HttpClient())
            {
                try
                {
                    string result = await client.GetStringAsync(url);
                    if (result.Trim().ToLower() == "true")
                    {
                        RConsoleWarn($"There is an active banwave going on as of {DateTime.Now.ToShortDateString()}. An alt is recommended.");
                    }
                    else
                    {
                        RConsoleInfo("No active banwaves detected. You should be safe to use your main account.");
                    }
                }
                catch (Exception ex)
                {
                    RConsoleErr("Error checking for ban wave: " + ex.Message);
                }
            }
        }

        private void InitializeFileSystemWatcher()
        {
            string scriptsFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");

            watcher = new FileSystemWatcher();
            watcher.Path = scriptsFolderPath;
            watcher.Filter = "*.*";
            watcher.NotifyFilter = NotifyFilters.FileName | NotifyFilters.LastWrite;
            watcher.IncludeSubdirectories = true;

            watcher.Created += OnChanged;
            watcher.Deleted += OnChanged;
            watcher.Renamed += OnRenamed;

            watcher.EnableRaisingEvents = true;
        }

        private void OnChanged(object sender, FileSystemEventArgs e)
        {
            // Update the list box when a file is created or deleted
            ListFilesInScriptsFolder();
        }

        private void OnRenamed(object sender, RenamedEventArgs e)
        {
            // Update the list box when a file is renamed
            ListFilesInScriptsFolder();
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                mouseDownPoint = e.Location;
                targetLocation = this.Location;
                moveTimer.Start();
            }
        }

        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                targetLocation = new Point(this.Location.X + e.X - mouseDownPoint.X, this.Location.Y + e.Y - mouseDownPoint.Y);
            }
        }

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                moveTimer.Stop();
            }
        }

        private void MoveTimer_Tick(object sender, EventArgs e)
        {
            int dx = (targetLocation.X - this.Location.X) / 10;
            int dy = (targetLocation.Y - this.Location.Y) / 10;
            this.Location = new Point(this.Location.X + dx, this.Location.Y + dy);
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            if (cxapi.Api.IsInjected())
            {
                cxapi.Api.Execute(fastColoredTextBox1.Text);
            }
            else
            {
                RConsoleWarn("Inject elysian into roblox before executing.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            fastColoredTextBox1.Text = "";
        }

        private async void button3_Click(object sender, EventArgs e)
        {
            if (Api.IsRobloxOpen())
            {
                RConsolePrint("Injecting...");
                Api.UserAgent("useragent", 1);
                cxapi.Api.Attach();
                System.Threading.Thread.Sleep(500);
                RConsolePrint("Elysian has successfully injected into " + Api.GetActiveClientNames());
            }
            else
            {
                RConsoleWarn("Open roblox before injecting elysian.");
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            // Handle text change event if needed
        }

        public void RConsolePrint(string message, string color = "WHITE", string[] pattern = null)
        {
            textBox1.AppendText(Environment.NewLine + "[ + ]  -  " + message);
        }

        public void RConsoleInfo(string message)
        {
            textBox1.AppendText(Environment.NewLine + "[ i ]  -  " + message);
        }

        public void RConsoleWarn(string message)
        {
            textBox1.AppendText(Environment.NewLine + "[ ⚠️ ]  -  " + message);
        }

        public void RConsoleErr(string message)
        {
            textBox1.AppendText(Environment.NewLine + "[ ERR ]  -  " + message);
        }

        public void RConsoleClear()
        {
            textBox1.Clear();
        }

        public void RConsoleName(string title)
        {
            this.Text = title;
        }

        public string RConsoleInput(string prompt = "")
        {
            // Since there's no network, we will just return a static input for now
            return "Static Input";
        }

        public void RConsoleCreate()
        {
            // No implementation needed for local printing
        }

        private void fastColoredTextBox1_Load(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // Add the call to list files on form load
            ListFilesInScriptsFolder();
        }

        private void ListFilesInScriptsFolder()
        {
            // Define the path to the scripts folder
            string scriptsFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");

            // Get the .lua, .txt, and .luau files in the scripts folder
            string[] files = Directory.GetFiles(scriptsFolderPath, "*.*", SearchOption.AllDirectories)
                .Where(file => file.EndsWith(".lua") || file.EndsWith(".txt") || file.EndsWith(".luau")).ToArray();
            listBox1.Items.Clear(); // Clear the list box before adding items
            foreach (string file in files)
            {
                listBox1.Items.Add(Path.GetFileName(file));
            }
        }

        private void ListBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem != null)
            {
                string selectedFile = listBox1.SelectedItem.ToString();
                string scriptsFolderPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
                string filePath = Path.Combine(scriptsFolderPath, selectedFile);

                if (File.Exists(filePath))
                {
                    string fileContents = File.ReadAllText(filePath);
                    Clipboard.SetText(fileContents);
                    RConsolePrint("Copied " + selectedFile + " to clipboard.");
                }
                else
                {
                    RConsoleWarn("Selected file does not exist.");
                }
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            using (SaveFileDialog saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.InitialDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
                saveFileDialog.Filter = "Lua files (*.lua)|*.lua|LuaU files (*.luau)|*.luau|Text files (*.txt)|*.txt";
                saveFileDialog.DefaultExt = "lua"; // Default file extension

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = saveFileDialog.FileName;
                    File.WriteAllText(filePath, fastColoredTextBox1.Text);
                    RConsolePrint("File saved: " + filePath);
                }
                else
                {
                    RConsoleInfo("Save operation was canceled.");
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.InitialDirectory = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "scripts");
                openFileDialog.Filter = "Lua files (*.lua)|*.lua|LuaU files (*.luau)|*.luau|Text files (*.txt)|*.txt";
                openFileDialog.DefaultExt = "lua"; // Default file extension

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string filePath = openFileDialog.FileName;
                    fastColoredTextBox1.Text = File.ReadAllText(filePath);
                    RConsoleInfo("File loaded: " + filePath);
                }
                else
                {
                    RConsoleInfo("Open operation was canceled.");
                }
            }
        }

        private void CheckBox1_CheckChanged(
            object sender,
            EventArgs e)
        {
            this.TopMost = checkBox1.Checked;
            if (checkBox1.Checked)
            {
                RConsoleInfo("Elysian is now above all windows.");
            }
            else
            {
                RConsoleInfo("Elysian is no longer above all windows.");
            }
        }
    }
}
